module.exports = {

  MLAB_KEY: "mongodb://db_reut:db_3366@ds119490.mlab.com:19490/private_messages"
}
 
